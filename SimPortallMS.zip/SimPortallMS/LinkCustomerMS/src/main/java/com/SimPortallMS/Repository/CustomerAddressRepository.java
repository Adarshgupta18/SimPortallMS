package com.SimPortallMS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SimPortallMS.Entity.CustomerAddress;

public interface CustomerAddressRepository extends JpaRepository<CustomerAddress, Integer>{

}
