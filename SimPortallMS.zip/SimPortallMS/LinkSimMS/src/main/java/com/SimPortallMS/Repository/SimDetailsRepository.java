package com.SimPortallMS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SimPortallMS.Entity.SimDetails;

public interface SimDetailsRepository extends JpaRepository<SimDetails, Integer>{

	SimDetails findByServiceNumberAndSimNumber(String serviceNumber, String simNumber);
}
